Welcome to Localhost!

INSTALLATION INSTRUCTIONS
=========================

1. Run the Installer
   -----------------
   This sets up the AI brain on your computer.
   Open Terminal, drag the `install.sh` file into the window, and hit Enter.
   
   Or run:
   ./install.sh

2. Install the App
   ---------------
   Drag 'Localhost.app' to your Applications folder.

3. Run
   ---
   Launch Localhost from Applications.
   Press Cmd+Shift+. to start chatting!

Enjoy!
